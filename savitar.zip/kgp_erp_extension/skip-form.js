// Original Author:
// https://github.com/rohitner/
// Skips ERP annoying form that pops up
window.setTimeout(() => {
    document.getElementById("skiplink").click();
}, 5000);